package com.daobao.asus.iweather.net.CallBack;

/**
 * Created by ASUS on 2017/10/29.
 */

public interface IError {
    void onError(int code, String msg);
}
