package com.daobao.asus.iweather.net.CallBack;

/**
 * Created by ASUS on 2017/10/29.
 */

public interface ISuccess {
    void onSuccess(String response);
}
